import java.util.Date;

public abstract class Appointment {
    private Doctor doctor;
    private Patient patient;
    private String notes;
    private Date date;

    private String time;

    public Appointment(Doctor doctor, Patient patient, String notes, Date date, String time){
        this.doctor = doctor;
        this.patient = patient;
        this.notes = notes;
        this.date =date;
        this.time = time;
    }

    public Doctor getDoctor(){
        return this.doctor;
    }

    public void setDoctor(Doctor doctor){
        this.doctor=doctor;
    }

    public Patient getPatient(){
        return this.patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String notes(){
        return this.notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Date date(){
        return this.date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String time(){
        return this.time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
