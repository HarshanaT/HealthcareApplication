import java.util.*;

public class Controller {
    public static ArrayList<Doctor> allDoctors = new ArrayList<>();
    public static ArrayList<Patient> allPatients = new ArrayList<>();
    public static int NUMBER_OF_SLOTS = 2;
    public static void addDoctor(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your name: ");
        String name = scanner.next();

        System.out.println("Enter your birthday: ");
        String birthday = scanner.next();

        System.out.println("Enter your specialisation: ");
        String specialisation = scanner.next();

        System.out.println("Enter your contact number: ");
        String contact = scanner.next();

        Random random = new Random();
        Doctor tempDoctor = new Doctor(random.nextInt(), name, birthday, specialisation, contact);

        allDoctors.add(tempDoctor);
    }

    public static void addAvailabilityForDoctor(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the doctor ID you want to add availability: ");
        int docId = scanner.nextInt();
        Doctor selectedDoctor = null;

        //we need to fetch the doctor from the arraylist
        for (Doctor doctor: allDoctors) {
            if(doctor.getDocId() == docId){
                selectedDoctor = doctor;  // if the doctor id entered by user matches the doctor id already in the system then assign that doctor object to selectedDoctor variable
            }
        }
        //if the doctor does not exist, we need to sout "No Doctor found"
        if(selectedDoctor == null){
            System.out.println("No doctor found");
            return;   // code below would not be executed as there is no doctor
        }
        //if the doctor exists, take the time
        System.out.println("Enter the day you want to add availability: ");
        int day = scanner.nextInt();
        System.out.println("Enter the month you want to add availability: ");
        int month = scanner.nextInt();
        System.out.println("Enter the year you want to add availability: ");
        int year = scanner.nextInt();

        Date bookingDate = new Date(year, month, day);
        selectedDoctor.setAvailability(bookingDate);  // set the availability of the doctor entered by the user who is available in the system

    }

    public static void viewAllDoctors() {
        for (Doctor doc : allDoctors) {
            System.out.println(doc.getName() + " has a specialisation of " + doc.getDocSpecialisation() + " has a ID of " + doc.getDocId() + " and has availability of " + doc.getAvailability().toString());
            System.out.println(doc.getDocId());
        }
    }
    public static void addPatient(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter patient name: ");
        String name = scanner.next();

        System.out.println("Enter patient's ID: ");
        String id = scanner.next();

        System.out.println("Enter patient's contact information: ");
        String contact = scanner.next();

        Patient tempPatient = new Patient(id,name,contact);
        allPatients.add(tempPatient);
        System.out.println("Patient is added successfully!");
        System.out.println(allPatients.toString());
    }
    public static void bookAppointment() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Doctor's ID you want to make an appointment: ");
        int docId = scanner.nextInt();

        System.out.println("Enter your patient ID: ");
        String patientId = scanner.next();

        System.out.println("Enter notes: ");
        String notes = scanner.next();
        scanner.nextLine();

        System.out.println("Do you want to book general or referral appointment? (Press 'G' for General and 'R' for Referral): ");
        String userAppointmentChoice = scanner.next();

        System.out.println("Enter the day you want to add appointment: ");
        String day = scanner.next();

        System.out.println("Enter the month you want to add appointment: ");
        String month = scanner.next();

        System.out.println("Enter the year you want to add appointment: ");
        String year = scanner.next();


        //get patient and doctor
        Patient selectedPatient = getPatientById(patientId);
        Doctor selectedDoc = getDoctorById(docId);


        if (selectedDoc == null || selectedPatient == null) {
            System.out.println("Invalid doctor or patient id");
            return;
        }
        Date appointmentDate = new Date(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));

        // Checking availability
        Boolean isAvailable = checkAvailability(selectedDoc, appointmentDate);

        //is doc available on appointment date
        if(isAvailable){
            String appTime = getTimeForBooking(selectedDoc,appointmentDate);
            if(appTime != null){
                if (userAppointmentChoice.equalsIgnoreCase("G")) {
                    Appointment generalAppointment = new GeneralAppointments(selectedDoc, selectedPatient, notes, appointmentDate, appTime, "");
                    selectedDoc.setAppointment(generalAppointment, appointmentDate);
                    System.out.println(selectedDoc.getAllAppointments().toString());
                } else if (userAppointmentChoice.equalsIgnoreCase("R")) {
                    System.out.println("Enter Referral Doctor's ID you want to make an appointment: ");
                    int refDocId = scanner.nextInt();
                    Doctor selectedRefDoc = getDoctorById(refDocId);

                    if (selectedRefDoc == null) {
                        System.out.println("Invalid doctor or patient id");
                    } else {
                        System.out.println("Enter Referral Doctor's Notes: ");
                        String refNotes = scanner.next();

                        ReferralAppointments referralAppointment = new ReferralAppointments(selectedDoc, selectedPatient, notes, appointmentDate, appTime, selectedRefDoc);
                        referralAppointment.setReferralDoctorNotes(refNotes);

                        selectedRefDoc.setAppointment(referralAppointment, appointmentDate);
                        System.out.println(selectedRefDoc.getAllAppointments().toString());

                    }
                }
            }
            else {
                System.out.println("All the slots are filled");
            }
            //        calculate appointment Time and slot availability
            //        make the appointment
        }
        else {
            System.out.println("Doctor is not available on the selected Date");
        }

    }
    private static String getTimeForBooking(Doctor selectDoctor, Date dateOfBooking){
        for(Map.Entry<Date,ArrayList<Appointment>> appointment: selectDoctor.getAllAppointments().entrySet()){  //entrySet() is an inbuilt method
            if (appointment.getKey().equals(dateOfBooking)){
                int numberOfSlots = appointment.getValue().size();
                if(numberOfSlots > NUMBER_OF_SLOTS-1){
                    return null;
                }
                System.out.println("We can make a booking");
                int time= 17+appointment.getValue().size();
                String strTime = time + " : 00";
                return strTime;
            }
        }
        return "17:00";
    }

    private static Boolean checkAvailability(Doctor selectedDoctor, Date dateOfBooking){
        for(Date day: selectedDoctor.getAvailability()){
            if(day.equals(dateOfBooking)){
                return true;
            }
        }
        return false;
    }

    //View a selected doctor's bookings
    public static void viewSelectedDoctorBooking(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter doctor ID to check a doctor's list of bookings: ");
        int docId = scanner.nextInt();
        Doctor viewDoc = getDoctorById(docId);

        if (viewDoc == null) {
            System.out.println("Invalid doctor ID");
            return;
        }else {
            Doctor selectedDoc = getDoctorById(docId);
            System.out.println(selectedDoc.getAllAppointments());
        }
    }

    public static Patient getPatientById(String id) {
        for (Patient patient : allPatients) {
            if(patient.getPatientID().equals(id)){
                return patient;
            }
        }
        return null;
    }
    public static Doctor getDoctorById(int id) {
        for (Doctor doc : allDoctors) {
            if(doc.getDocId() == id){
                return doc;
            }
        }
        return null;
    }

}
