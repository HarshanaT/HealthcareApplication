import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Doctor extends Person{   // Doctor Inherits from abstract class Person
    //make private
    private int docId;
    private String docBirthday;
    private String docSpecialisation;

    private ArrayList<Date> availability;  // to store available dates of doctors
    public HashMap<Date,ArrayList<Appointment>> allAppointments= new HashMap<>(); //Date is the key ; Appointment list is the value
    public Doctor(int id,String name, String birthday, String specialisation, String contactNumber){
        super(name,contactNumber);
        this.docId = id;
        this.docBirthday = birthday;
        this.docSpecialisation=specialisation;
        availability = new ArrayList<>();  //creating an array to check availability everytime a doctor object is created
    }
    public boolean  isPhysician(){
        return this.docSpecialisation.endsWith("Physician");
    }

    public void setAvailability(Date availableDate){
        this.availability.add(availableDate);
    }
    public void setAppointment(Appointment appointment, Date date){
        ArrayList<Appointment> currentAppointments = this.allAppointments.get(date);

        if (currentAppointments == null){   // if a new key is entered then it would not be there in the arraylist therefore would return null -> must create a new arraylist to store the new key and its values
            ArrayList<Appointment> tempArraylist = new ArrayList<>();
            tempArraylist.add(appointment);
            this.allAppointments.put(date,tempArraylist);
        }
        else{                               // if a key exists already in the list then the new values are added with the already existing values
            currentAppointments.add(appointment);
            this.allAppointments.put(date,currentAppointments);
        }
        //this.allAppointments.put(date,);
    }
    public int getDocId() {
        return this.docId;
    }

    public String getDocSpecialisation() {
        return docSpecialisation;
    }
    public ArrayList<Date> getAvailability() {
        return availability;
    }


    public HashMap<Date, ArrayList<Appointment>> getAllAppointments() {
        return allAppointments;
    }

    public void setAllAppointments(HashMap<Date, ArrayList<Appointment>> allAppointments) {
        this.allAppointments = allAppointments;
    }

}
