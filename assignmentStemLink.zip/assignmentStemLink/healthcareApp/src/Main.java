import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void admin(){
        Scanner scanner = new Scanner(System.in);

        while(true) {
            System.out.println("Press 1 to add a doctor, press 2 to add a doctor availability, and press 3 to exit");
            int userObjective = scanner.nextInt();

            if (userObjective == 1) {
                Controller.addDoctor();
                System.out.println("Doctor added successfully!");

            } else if (userObjective == 2) {
                //Add a doctor availability
                //Identify doctor through ID and set availability
                Controller.addAvailabilityForDoctor();
                System.out.println("Availability of the doctor has been added successfully!");

                //add the availability of the doctor

            } else if (userObjective == 3) {
                System.out.println("Exit");
                userChoice();
                break;
            } else {
                System.out.println("Invalid input");
            }
        }
    }

    public static void patient(){
        Scanner scanner = new Scanner(System.in);
        while(true) {
            System.out.println("Press 1 to view doctors, press 2 to book an appointment, press 3 to view a selected doctor's bookings, press 4 to add a patient and press 5 to exit");
            int userObjective = scanner.nextInt();

            if (userObjective == 1) {
                Controller.viewAllDoctors();
            } else if (userObjective == 2) {
                //Book an appointment
                Controller.bookAppointment();
            } else if (userObjective == 3) {
               Controller.viewSelectedDoctorBooking();
            } else if (userObjective == 4) {
                Controller.addPatient();
            } else if (userObjective == 5) {
                System.out.println("Exit");
                userChoice();
                return;
            } else {
                System.out.println("Invalid input");
            }
        }
    }
    public static void userChoice() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("If you are a hospital administrator please press 1, if you are a patient please press 2, press 3 to exit");
        int userType = scanner.nextInt();

        if (userType == 1) {
            admin();
        } else if (userType == 2) {
            patient();
        } else if (userType == 3) {
            System.out.println("Exit");
        } else {
            System.out.println("Invalid Input");

        }
    }
    public static void main(String[] args) {

        //For testing purpose
       Doctor sampleDoc = new Doctor(101,"John Smith","1990-01-01","Neuro Physician","071-854-8896");
       Doctor sampleDoc2 = new Doctor(102,"George Eric","2026-08-03","Neuro Physician","071-785-3456");
       Patient samplePatient = new Patient("T-1234","Alice Johnson","999-846-9848");
       Patient samplePatient2 = new Patient("T-5678","Yashika","077894655");

       Controller.allDoctors.add(sampleDoc);
       Controller.allDoctors.add(sampleDoc2);
       Controller.allPatients.add(samplePatient);
       Controller.allPatients.add(samplePatient2);

        userChoice();

    }
}