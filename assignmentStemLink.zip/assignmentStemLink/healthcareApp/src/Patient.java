public class Patient extends Person{
    private String patientID;

    public String getPatientID(){
        return this.patientID;
    }

    public Patient(String id,String name,String contactNumber){
        super(name,contactNumber);
        this.patientID = id;
    }

    public char getPatientType(){
       return patientID.charAt(0);
    }
}
