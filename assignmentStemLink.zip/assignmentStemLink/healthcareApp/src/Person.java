public abstract class Person {  //Abstract class Person created and inherited by Doctor and Patient classes as name and contact number are redundant in Doctor and Patient classes
    private String name;
    private String contactNumber;

    public Person(String name, String contactNumber){
        this.name = name;
        this.contactNumber = contactNumber;
    }

    public String getName() {
        return name;
    }

    public String getContactNumber() {
        return contactNumber;
    }
}
