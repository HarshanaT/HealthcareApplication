import java.util.Date;

public class ReferralAppointments extends Appointment {

    private Doctor referralDoctor;
    private String notes;
    private String referralDoctorNotes;

    public ReferralAppointments(Doctor doctor, Patient patient, String notes, Date date, String time, Doctor referralDoctor) {
        super(doctor, patient, notes, date, time);
        this.referralDoctor = referralDoctor;
        this.notes = notes;
    }

    public void setReferralDoctorNotes(String referralDoctorNotes) {
        this.referralDoctorNotes = referralDoctorNotes;
    }

    public void setReferralDoctorNotes(String[] referralDoctorNotes) {
        this.referralDoctorNotes = String.join(" ", referralDoctorNotes);
    }

    public Doctor getReferralDoctor() {
        return referralDoctor;
    }
    public void setReferralDoctor(Doctor referralDoctor) {
        this.referralDoctor = referralDoctor;
    }

    public String getNotes() {
        return notes;
    }

    @Override
    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getReferralDoctorNotes() {
        return referralDoctorNotes;
    }
}
